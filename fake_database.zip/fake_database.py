from typing import List, Optional
from models.book import Book
from helpers.file_helper import save_to_file, load_from_file

# Fake database (list of products)
book_db: List[Book] = []

#la create_db viene chiamata ua sola volta
def create_db():
    global books_db 
    books_db = [
        Book(id=1, title="Laptop", author="Electronics", price=float("999.99"), pages=123),
        Book(id=2, title="Laptop1", author="Electronics1", price=float("99.99"), pages=2123),       
    ]
    save_books()  # Save default data
    
def load_books():
    global books_db
    try:
        data = load_from_file("books.json")
        books_db = [Book(**b) for b in data]
    except FileNotFoundError:
        # If file doesn't exist, load default values
        create_db()    
    
def save_books():
    data = [p.serialize() for p in books_db]
    save_to_file(data, "books.json")
    
def get_all_books():
    """Returns all books."""
    return books_db 

def get_book_by_id(id) -> Optional[Book]:
    """Returns one book by id."""
    book = next((b for b in books_db if id == b.id), None)
    return book

def insert_book(book: Book) -> None:
    """Inserts a new book into the database."""
    try:
        new_id = max((b.id for b in books_db), default=0) + 1
        book.id = new_id    
        books_db.append(book)
        save_books()
    except:
        return None
    return new_id    

def update_book(book:Book, data) -> bool:
    if "title" in data:
        book.title = data["title"]
    if "author" in data:
        book.author = data["author"]   
    if "price" in data:
        book.price = float(data["price"])
    if "pages" in data:
        book.pages = int(data["pages"])
    try:
        save_books()
        return True
    except Exception as ex:
        print(ex) #stiamo visualizzando (dovremmo anche salvarlo) il log di un eventuale errore
        return False
    
def delete_book(book:Book) -> bool:
   global books_db
   try:
       books_db = [b for b in books_db if b.id != book.id]
       return True
   except Exception as ex:
       print(ex) #stiamo visualizzando (dovremmo anche salvarlo) il log di un eventuale errore
       return False