from flask import Flask, render_template, abort, request
from flask_cors import CORS #pip install flask_cors
from controllers.book_controller import book_controller
from fake_database import load_books

app = Flask(__name__)
app.register_blueprint(book_controller) #2-registrare un file di endpoint

CORS(app)

# funzione View
@app.route("/", methods = ['GET'])
def homepage():    
    return render_template('client_book.html')

def start_api():
    global config  
    load_books()  #workaround
    app.run(host='0.0.0.0', port=5001)    
    #app.run(debug = True)
    
# This allows us to run app.py directly too
if __name__ == '__main__':
    start_api()
